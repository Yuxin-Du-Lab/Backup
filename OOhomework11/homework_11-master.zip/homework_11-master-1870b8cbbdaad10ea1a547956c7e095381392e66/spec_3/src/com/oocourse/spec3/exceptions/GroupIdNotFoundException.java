package com.oocourse.spec3.exceptions;

public abstract class GroupIdNotFoundException extends Exception {

    public abstract void print();
}
