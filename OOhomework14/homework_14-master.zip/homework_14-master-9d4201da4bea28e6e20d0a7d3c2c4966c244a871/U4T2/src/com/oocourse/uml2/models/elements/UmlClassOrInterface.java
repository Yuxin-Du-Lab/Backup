package com.oocourse.uml2.models.elements;

import com.oocourse.uml2.models.common.Visibility;

public interface UmlClassOrInterface extends UmlElementInterface {
    Visibility getVisibility();
}
