package com.oocourse.uml2.utils.common;

/**
 * 入口点
 */
public interface Entrance {
    /**
     * 构造函数
     *
     * @param args 命令行参数
     */
    void run(String[] args);
}
