package com.oocourse.uml2.interact.common;

public enum AttributeQueryType {
    ALL,  // 各级父类
    SELF_ONLY  // 仅自身类
}
