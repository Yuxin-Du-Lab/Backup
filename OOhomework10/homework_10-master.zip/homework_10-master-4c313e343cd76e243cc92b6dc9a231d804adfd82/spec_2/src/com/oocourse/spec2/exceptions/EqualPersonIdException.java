package com.oocourse.spec2.exceptions;

public abstract class EqualPersonIdException extends Exception {

    public abstract void print();
}
