package com.oocourse.uml3.models.elements;

import com.oocourse.uml3.models.common.Visibility;

public interface UmlClassOrInterface extends UmlElementInterface {
    Visibility getVisibility();
}
